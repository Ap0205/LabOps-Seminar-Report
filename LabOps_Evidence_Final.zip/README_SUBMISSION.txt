LABOPS — FINAL SEMINAR SUBMISSION

Contents:
- LabOps_Empirical_Seminar_Report_Final.docx: editable report.
- LabOps_Empirical_Seminar_Report_Final.pdf: matching PDF (generated after layout validation).
- evidence/: original evidence archive contents plus clearly named supplemental screenshots.

Safety and integrity notes:
- The local training password visible in one uploaded screenshot was deliberately excluded. Do not submit that screenshot.
- Plaintext secrets.env, decrypted secrets, private GPG keys and password lists are not included.
- The original encrypted ciphertext bytes were not included in the uploaded evidence archive; a screenshot proves file presence only.
- The broad Hydra run also found stronguser; the report transparently records this deviation.
- All tests were local to the user's lab.
